import React from 'react';
import { useBlogPost } from '@docusaurus/plugin-content-blog/client';
import styles from './Header.module.css'; // Import the CSS file for custom styles

export default function BlogPostItemHeader() {
  const { metadata, isBlogPostPage } = useBlogPost();
  const { title, permalink, date, formattedDate, readingTime, authors } = metadata;

  return (
<header>
  <h1>
    {isBlogPostPage ? title : <a href={permalink}>{title}</a>}
  </h1>
  <p>
    <time dateTime={date}>{formattedDate}</time>
    {readingTime && ` · ${Math.ceil(readingTime)} min read`}
    {authors.length > 0 && (
      <>
        {' | '}
        {authors.map((author) => `${author.name}${author.title ? `, ${author.title}` : ''}`).join(' · ')}
      </>
    )}
  </p>
</header>
  );
}




